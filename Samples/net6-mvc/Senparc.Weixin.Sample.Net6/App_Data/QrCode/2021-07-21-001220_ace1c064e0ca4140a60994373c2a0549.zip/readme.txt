## 说明

本文件夹用于存放已生成的二维码。

二维码生成地址：https://sdk.weixin.senparc.com/QrCode

源代码已 100% 对外开放，包含在 https://github.com/JeffreySu/WeiXinMPSDK 项目的 Sample 中（QrCodeController.cs）。


## 特别说明

二维码生成及使用应遵守国家法律及道德约束，保存或使用此二维码即表示操作者愿意承担所有责任。

盛派网络 保留所有权利。